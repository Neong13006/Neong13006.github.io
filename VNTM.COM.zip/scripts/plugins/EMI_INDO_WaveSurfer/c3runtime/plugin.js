
const C3 = globalThis.C3;

C3.Plugins.EMI_INDO_WaveSurfer = class EMI_INDO_WaveSurferPlugin extends globalThis.ISDKPluginBase
{
	constructor()
	{
		super();
	}
}; 