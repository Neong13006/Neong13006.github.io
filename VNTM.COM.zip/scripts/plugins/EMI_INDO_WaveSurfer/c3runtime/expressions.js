
    globalThis.C3.Plugins.EMI_INDO_WaveSurfer.Exps = {
	
 

    }; 