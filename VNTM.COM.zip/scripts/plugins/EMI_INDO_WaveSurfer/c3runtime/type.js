
const C3 = globalThis.C3;

C3.Plugins.EMI_INDO_WaveSurfer.Type = class EMI_INDO_WaveSurferType extends globalThis.ISDKObjectTypeBase
{
	constructor()
	{
		super();
	}
	
	_onCreate()
	{
	}
}; 